package runner

import (
	"io"
	"log"
	"regexp"
	"strings"

	"github.com/logrusorgru/aurora"
)

type resultStatus string

const (
	ResultHTTPError     resultStatus = "http error"
	ResultResponseError resultStatus = "response error"
	ResultVulnerable    resultStatus = "vulnerable"
	ResultNotVulnerable resultStatus = "not vulnerable"
)

type Result struct {
	ResStatus    resultStatus
	Status       aurora.Value
	Entry        Fingerprint
	ResponseBody string
	Subdomain    string
	CName        []string
	Vulnerable   bool
	Service      string
}

func (c *Config) checkSubdomain(subdomain string) Result {
	// Step 1: Resolve DNS
	dnsResult := ResolveSubdomain(subdomain)

	// Step 2: Build URL
	url := subdomain
	if !isValidUrl(url) {
		if c.HTTPS {
			url = "https://" + subdomain
		} else {
			url = "http://" + subdomain
		}
	}

	// Step 3: HTTP Request
	resp, err := c.client.Get(url)
	if err != nil {
		return Result{
			ResStatus:    ResultHTTPError,
			Status:       aurora.Red("HTTP ERROR"),
			Entry:        Fingerprint{},
			ResponseBody: "",
			Subdomain:    subdomain,
			CName:        dnsResult.CNAMEs,
			Vulnerable:   false,
			Service:      "",
		}
	}
	defer resp.Body.Close()

	bodyBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return Result{
			ResStatus:    ResultResponseError,
			Status:       aurora.Red("RESPONSE ERROR"),
			Entry:        Fingerprint{},
			ResponseBody: "",
			Subdomain:    subdomain,
			CName:        dnsResult.CNAMEs,
			Vulnerable:   false,
			Service:      "",
		}
	}

	body := string(bodyBytes)

	// Step 4: Fingerprint Matching
	for _, fp := range c.fingerprints {
		// Match by NXDOMAIN flag
		if fp.NXDomain && dnsResult.NXDomain {
			return Result{
				ResStatus:    ResultVulnerable,
				Status:       aurora.Green("VULNERABLE (NXDOMAIN)"),
				Entry:        fp,
				ResponseBody: body,
				Subdomain:    subdomain,
				CName:        dnsResult.CNAMEs,
				Vulnerable:   true,
				Service:      fp.Service,
			}
		}

		// Match body content regex
		if confirmsVulnerability(body, fp) {
			return Result{
				ResStatus:    ResultVulnerable,
				Status:       aurora.Green("VULNERABLE"),
				Entry:        fp,
				ResponseBody: body,
				Subdomain:    subdomain,
				CName:        dnsResult.CNAMEs,
				Vulnerable:   true,
				Service:      fp.Service,
			}
		}
	}

	// Default result
	return Result{
		ResStatus:    ResultNotVulnerable,
		Status:       aurora.Red("NOT VULNERABLE"),
		Entry:        Fingerprint{},
		ResponseBody: body,
		Subdomain:    subdomain,
		CName:        dnsResult.CNAMEs,
		Vulnerable:   false,
		Service:      "",
	}
}

func confirmsVulnerability(body string, fp Fingerprint) bool {
	if fp.NXDomain {
		return false
	}

	if fp.Fingerprint != "" {
		re, err := regexp.Compile(fp.Fingerprint)
		if err != nil {
			log.Printf("Regex error for fingerprint %s: %v", fp.Fingerprint, err)
			return false
		}
		if re.MatchString(body) {
			return true
		}
	}

	return false
}
