package runner

import (
	"net"
	"strings"
	"time"
)

type DNSResult struct {
	CNAMEs    []string
	NXDomain  bool
	Resolved  bool
}

func ResolveSubdomain(sub string) DNSResult {
	var result DNSResult

	resolver := &net.Resolver{
		PreferGo: true,
		Dial: func(_, _ string) (net.Conn, error) {
			d := net.Dialer{
				Timeout: 5 * time.Second,
			}
			return d.Dial("udp", "8.8.8.8:53")
		},
	}

	cname, err := resolver.LookupCNAME(nil, sub)
	if err != nil {
		if strings.Contains(err.Error(), "no such host") {
			result.NXDomain = true
		}
		return result
	}

	result.CNAMEs = append(result.CNAMEs, strings.TrimSuffix(cname, "."))
	result.Resolved = true
	return result
}
