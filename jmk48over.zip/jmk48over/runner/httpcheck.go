package runner

import (
	"io"
	"log"
	"net/http"
	"regexp"
	"strings"

	"github.com/logrusorgru/aurora"
)

type resultStatus string

const (
	ResultVulnerable    resultStatus = "vulnerable"
	ResultNotVulnerable resultStatus = "not vulnerable"
	ResultHTTPError     resultStatus = "http error"
)

type Result struct {
	ResStatus    resultStatus
	Status       aurora.Value
	Entry        Fingerprint
	ResponseBody string
}

func CheckHTTP(subdomain string) Result {
	url := "http://" + subdomain
	resp, err := http.Get(url)
	if err != nil {
		return Result{ResStatus: ResultHTTPError}
	}
	defer resp.Body.Close()

	bodyBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return Result{ResStatus: ResultHTTPError}
	}

	body := string(bodyBytes)
	fpList, _ := Fingerprints()

	for _, fp := range fpList {
		if fp.Fingerprint != "" {
			re, err := regexp.Compile(fp.Fingerprint)
			if err != nil {
				log.Printf("Regex error for %s: %v", fp.Fingerprint, err)
				continue
			}
			if re.MatchString(body) {
				return Result{
					ResStatus:    ResultVulnerable,
					Status:       aurora.Green("VULNERABLE"),
					Entry:        fp,
					ResponseBody: body,
				}
			}
		}
	}
	return Result{ResStatus: ResultNotVulnerable}
}
