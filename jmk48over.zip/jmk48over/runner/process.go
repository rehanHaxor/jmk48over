package runner

import (
	"fmt"
	"os"
	"strings"
)

func Process(cfg *Config) error {
	// 1. Init HTTP client
	cfg.initHTTPClient()

	// 2. Load fingerprints
	err := cfg.loadFingerprints()
	if err != nil {
		return fmt.Errorf("failed to load fingerprints: %v", err)
	}

	// 3. Ambil target dari --targets (file) atau --target (inline)
	var subdomains []string

	if cfg.Targets != "" {
		subs, err := readSubdomains(cfg.Targets)
		if err != nil {
			return fmt.Errorf("failed to read file %s: %v", cfg.Targets, err)
		}
		subdomains = append(subdomains, subs...)
	}

	if cfg.Target != "" {
		for _, s := range strings.Split(cfg.Target, ",") {
			s = strings.TrimSpace(s)
			if s != "" {
				subdomains = append(subdomains, s)
			}
		}
	}

	if len(subdomains) == 0 {
		return fmt.Errorf("no subdomains provided (use --target or --targets)")
	}

	fmt.Printf("[*] Loaded %d subdomains\n", len(subdomains))

	// 4. Jalankan scan
	results, err := cfg.RunScan(subdomains)
	if err != nil {
		return fmt.Errorf("failed to scan: %v", err)
	}

	// 5. Tampilkan hasil
	for _, res := range results {
		if cfg.OnlyVuln && !res.Vulnerable {
			continue
		}
		if res.Vulnerable {
			fmt.Printf("[🔥] %s → %s (%s)\n", res.Subdomain, strings.Join(res.CName, ","), res.Service)
		} else if !cfg.HideFails {
			fmt.Printf("[~] %s → %s (%s)\n", res.Subdomain, strings.Join(res.CName, ","), res.Service)
		}
	}

	// 6. Simpan jika ada --output
	if cfg.Output != "" {
		basePath := strings.TrimSuffix(cfg.Output, ".json")
		err := SaveResults(results, basePath)
		if err != nil {
			return fmt.Errorf("failed to save results: %v", err)
		}
		fmt.Printf("[✓] Results saved to %s.json and %s.txt\n", basePath, basePath)
	}

	return nil
}
 