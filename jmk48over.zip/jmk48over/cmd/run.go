package cmd

import (
	"errors"
	"fmt"
	"io/fs"
	"os"

	"github.com/rehanHaxor/jmk48over/runner"
	"github.com/spf13/cobra"
)

var opts = runner.Config{}

var gasCmd = &cobra.Command{
	Use:     "gas",
	Short:   "🔥 Gas jmk48over untuk scan subdomain takeover",
	Aliases: []string{"g"},
	RunE: func(cmd *cobra.Command, args []string) error {
		fingerprintsPath, err := runner.GetFingerprintPath()
		if err != nil {
			return err
		}

		if _, err := os.Stat(fingerprintsPath); errors.Is(err, fs.ErrNotExist) {
			fmt.Printf("[ * ] Fingerprints not found; saving them to %q\n", fingerprintsPath)
			if err := runner.DownloadFingerprints(); err != nil {
				return err
			}
		} else {
			fmt.Println("[ * ] Fingerprints found; checking integrity with upstream...")
			valid, err := runner.CheckIntegrity()
			if err != nil {
				return err
			}
			if !valid {
				fmt.Println("[ * ] Integrity mismatch! Re-downloading fingerprints.")
				if err := runner.DownloadFingerprints(); err != nil {
					return err
				}
			}
		}

		// Jalankan proses utama
		if err := runner.Process(&opts); err != nil {
			return err
		}
		return nil
	},
}

func init() {
	gasCmd.Flags().StringVar(&opts.Target, "target", "", "🔎 Comma separated list of subdomains")
	gasCmd.Flags().StringVar(&opts.Targets, "targets", "", "📄 File berisi daftar subdomain")
	gasCmd.Flags().StringVar(&opts.Output, "output", "", "💾 Simpan hasil dalam format JSON")
	gasCmd.Flags().BoolVar(&opts.HTTPS, "https", false, "🌐 Paksa HTTPS jika tidak ada protokol")
	gasCmd.Flags().BoolVar(&opts.VerifySSL, "verify_ssl", false, "🔒 Verifikasi SSL (default: false)")
	gasCmd.Flags().BoolVar(&opts.HideFails, "hide_fails", false, "🙈 Sembunyikan hasil yang gagal")
	gasCmd.Flags().BoolVar(&opts.OnlyVuln, "vuln", false, "🔥 Simpan hanya subdomain yang rentan")
	gasCmd.Flags().IntVar(&opts.Concurrency, "concurrency", 10, "⚙️ Jumlah pengecekan paralel")
	gasCmd.Flags().IntVar(&opts.Timeout, "timeout", 10, "⏱️ Timeout request dalam detik")

	rootCmd.AddCommand(gasCmd)
}
