package cmd

import (
	"bufio"
	"fmt"
	"os"
	"strings"

	"github.com/rehanHaxor/jmk48over/runner"
	"github.com/spf13/cobra"
)

var (
	inputFile   string
	outputFile  string
	doUpdate    bool
	silentMode  bool
	httpCheck   bool
)

var (
	green  = "\033[32m"
	red    = "\033[31m"
	yellow = "\033[33m"
	blue   = "\033[34m"
	reset  = "\033[0m"
)

var rootCmd = &cobra.Command{
	Use:   "jmk48over",
	Short: "🔥 jmk48over - Subdomain Takeover Detection Tool",
	Long: `🚀 jmk48over is a fast and automated subdomain takeover scanner 
inspired by Subzy. Built with 💖 by rehanHaxor.

Examples:
  jmk48over --gas subdomains.txt --output hasil
  jmk48over --gas input.txt --silent --http --output vuln_result`,
	Run: func(cmd *cobra.Command, args []string) {
		// Step 1: Update fingerprints if requested
		if doUpdate {
			fmt.Println(blue + "[*] Checking fingerprint updates..." + reset)
			if err := runner.UpdateFingerprints(); err != nil {
				fmt.Printf(red+"[x] Update failed: %v\n"+reset, err)
				os.Exit(1)
			}
			fmt.Println(green + "[✓] Fingerprints are up to date." + reset)
		}

		// Step 2: Validate input
		if inputFile == "" {
			fmt.Println(red + "[x] Please provide input using --gas <file>" + reset)
			cmd.Help()
			os.Exit(1)
		}

		// Step 3: Parse subdomains
		subdomains, err := parseInputFile(inputFile)
		if err != nil {
			fmt.Printf(red+"[x] Failed to read input file: %v\n"+reset, err)
			os.Exit(1)
		}
		fmt.Printf(green+"[+] Loaded %d subdomains from %s\n"+reset, len(subdomains), inputFile)

		// Step 4: Run scanner
		results, err := runner.RunScan(subdomains, httpCheck)
		if err != nil {
			fmt.Printf(red+"[x] Scan failed: %v\n"+reset, err)
			os.Exit(1)
		}

		// Step 5: Print results
		for _, res := range results {
			msg := fmt.Sprintf("%s → %s (%s)", res.Subdomain, strings.Join(res.CName, ","), res.Service)
			if res.Vulnerable {
				if !silentMode {
					fmt.Printf(red+"[🔥] %s\n"+reset, msg)
				}
			} else {
				if !silentMode {
					fmt.Printf(yellow+"[~] %s\n"+reset, msg)
				}
			}
		}

		// Step 6: Save results
		if outputFile != "" {
			basePath := strings.TrimSuffix(outputFile, ".json")
			err := runner.SaveResults(results, basePath)
			if err != nil {
				fmt.Printf(red+"[x] Failed to save output: %v\n"+reset, err)
			} else {
				fmt.Printf(green+"[✓] Results saved to %s.json and %s.txt\n"+reset, basePath, basePath)
			}
		}
	},
}

// Execute - called by main.go
func Execute() {
	rootCmd.Flags().StringVar(&inputFile, "gas", "", "🔥 Input file to scan (list of subdomains)")
	rootCmd.Flags().StringVar(&outputFile, "output", "", "💾 Save results to file (no extension)")
	rootCmd.Flags().BoolVar(&doUpdate, "update", false, "🔁 Update fingerprint database")
	rootCmd.Flags().BoolVar(&silentMode, "silent", false, "🤫 Only show vulnerable subdomains")
	rootCmd.Flags().BoolVar(&httpCheck, "http", false, "🔍 Enable HTTP body fingerprint check for matching signatures")

	cobra.CheckErr(rootCmd.Execute())
}

// Helper: parse subdomains from file
func parseInputFile(path string) ([]string, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var subs []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line != "" {
			subs = append(subs, line)
		}
	}
	return subs, scanner.Err()
}
