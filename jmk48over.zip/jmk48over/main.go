package main

import (
	"github.com/rehanHaxor/jmk48over/cmd"
)

func main() {
	cmd.Execute()
}
